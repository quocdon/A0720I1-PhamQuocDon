# typescript-demo
Thực hành kiến thức về TypeScript.

Lưu ý sử dụng nodejs 8.

Khuyến khích sử dụng https://github.com/tj/n để chuyển đổi linh hoạt giữa các phiên bản nodejs.
