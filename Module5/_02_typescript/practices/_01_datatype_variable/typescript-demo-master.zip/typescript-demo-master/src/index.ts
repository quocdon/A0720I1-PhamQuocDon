import './scss/styles.scss';
console.log(`it's work!`);

