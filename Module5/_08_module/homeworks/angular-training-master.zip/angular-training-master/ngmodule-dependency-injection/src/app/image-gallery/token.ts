import { InjectionToken } from '@angular/core';

export const GalleryConfig = new InjectionToken<number>('GalleryConfig');
