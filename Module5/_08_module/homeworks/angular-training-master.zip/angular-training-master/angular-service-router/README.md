# AngularServiceRouter

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.1.5.

## Hướng dẫn

1. Các bạn vào trang repo dự án để clone/download về `git clone link-repo`.
2. Sau khi clone về, các bạn cần cài đặt Nodejs, Angular CLI
3. Di chuyển terminal/CMD vào folder code vừa clone về, sau đó chạy `npm i` để cài đặt các packages cần thiết
4. Mở project mẫu với editor mà các bạn quen thuộc (khuyến cáo dùng VS Code), các bạn sẽ hình thấy structure như trên.
5. Chạy lệnh `ng serve -o`, sau đó trình duyệt sẽ tự động mở trang web [localhost:4200](http://localhost:4200), các bạn có thể nhìn thấy giao diện đã có sẵn ví dụ về bài thực hành.
