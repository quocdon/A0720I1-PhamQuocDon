package cg.wbd.grandemonstration.repository;

import cg.wbd.grandemonstration.model.Province;
import org.springframework.data.repository.CrudRepository;

public interface ProvinceRepository extends CrudRepository<Province, Long> {
}
