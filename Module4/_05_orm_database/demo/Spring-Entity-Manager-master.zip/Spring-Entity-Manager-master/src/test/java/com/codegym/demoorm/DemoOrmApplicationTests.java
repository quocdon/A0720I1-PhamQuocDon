package com.codegym.demoorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOrmApplicationTests {

    @Test
    void contextLoads() {
    }

}
