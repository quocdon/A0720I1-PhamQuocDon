package com.codegym.demoorm.repository;

import com.codegym.demoorm.model.Customer;

public interface CustomerRepository extends Repository<Customer> {
}